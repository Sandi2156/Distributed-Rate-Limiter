1. This will act as a middleware
2. Flow
    i. User first login to our portal
    ii. He'll register some apis (authentication check must be present)
    iii. For each api select rule and configure it